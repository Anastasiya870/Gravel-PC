# bone_collector
Mod for minetest game. Allow to craft clay, gravel, sand, coal or dirt from bone nodes.
