# Gravel
A module to make graphs in V 
(still a work in progress)

## Install
```v
v install substicker.Gravel
```
![](docs/horizontalbar.gif)